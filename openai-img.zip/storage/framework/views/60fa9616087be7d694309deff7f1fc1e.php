<?php $__env->startSection('title', 'Image Generator with OpenAI'); ?>

<?php $__env->startSection('styles'); ?>

    <style>
        .card {
            background-image:linear-gradient(to top, #a8edea 0%, #fed6e3 100%);
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col col-md-6">
            <div class="card">
                <div class="card-header text-center">
                    <h3>Image Generator with OpenAI</h3>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('generate')); ?>" method="POST" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label">Imagine anything and write down below:</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="desc" id="desc" maxlength="1000" placeholder="Writing a love letter to her" value="<?php echo e(old('desc')); ?>" required>
                            <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e(__('Provide provide a valid description')); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Please select a size of the image</label>
                            <select class="form-select <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="size">
                                <option selected>Open this select menu</option>
                                <option value="sm <?php if(old('size') === 'sm'): ?> selected <?php endif; ?>">Small</option>
                                <option value="md <?php if(old('size') === 'md'): ?> selected <?php endif; ?>">Medium</option>
                                <option value="lg <?php if(old('size') === 'lg'): ?> selected <?php endif; ?>">Large</option>
                            </select>
                            <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e(__('Provide provide a valid size')); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-secondary mt-2 mb-3 w-100">Generate Image</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\openai-img\resources\views/home.blade.php ENDPATH**/ ?>